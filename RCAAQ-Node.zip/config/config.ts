export default {
    JWTKEY: process.env.JWTKEY,
    MONGODB: process.env.MONGODB
}