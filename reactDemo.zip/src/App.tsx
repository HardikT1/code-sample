import React, { Suspense } from 'react';
import 'antd/dist/antd.css';
import Routes from './router';
import Spinner from './components/Spinner';
import { history } from "./Redux/store";
import Boot from './Redux/boot';
require('dotenv').config()

function App() {

  return (
    <Suspense fallback={<Spinner />}>
      <Routes history={history} />
    </Suspense>
  );
}

Boot()
  .then(() => App())
  .catch((error) => error);

export default App;
