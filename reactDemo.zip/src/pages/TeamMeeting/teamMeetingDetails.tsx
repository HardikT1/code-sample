import React from 'react'
import { Typography, Row, Col, Table, Form } from "antd";
import { CoffeeOutlined, FileSearchOutlined, UsergroupAddOutlined } from '@ant-design/icons';
import AppLayout from '../../components/layout/layout';

const TeamMeetingDetails = () => {
  const { Title } = Typography;
  const columns = [
    {
      title: 'Date',
      dataIndex: 'date',
    },
    {
      title: 'Living Environment',
      dataIndex: 'livingEnvironment',
    },
    {
      title: 'Visiting Members',
      dataIndex: 'visiter',
    },
    {
      title: 'Non Member Visitors',
      dataIndex: 'nonVisiter',
    },
    {
      title: 'Total Visitors',
      dataIndex: 'totalVisiter',
    },

  ];

  const data: any = [];
  for (let i = 1; i <= 10; i++) {
    data.push({
      key: i,
      livingEnvironment: 'abbccc',
      date: "26/6/1997",
      visiter: 12,
      nonVisiter: 2,
      totalVisiter: 13
    });
  }

  const tableColumns = columns.map((item) => ({
    ...item,
  }));

  return (
    <AppLayout>
      <div>
        <Row>
          <Col span={1}>
            <CoffeeOutlined style={{ fontSize: '35px' }} />
          </Col>
          <Col span={23}>
            <Typography className={'title-fontStyle '}>
              TITLE
            </Typography>
          </Col>
        </Row>
      </div>
      <div className={'margin-20'}>
        <Row justify='space-between' >
          <Col span={1}>
            <FileSearchOutlined style={{ fontSize: '30px' }} />
          </Col>
          <Col span={23}>
            <Typography className={'font-title-member '}>
              INFORMATIONS
            </Typography>
          </Col>
        </Row>
      </div>
      <div className={'margin-20'}>
        <div className={'form-block'}>
          <Row>
            <Col span={12}>
              <Row>
                <Col span={24}>
                  <Form>
                    <Row>
                      <Col span={6}>
                        <div className={'form-label'}>
                          <Title level={5}>Title</Title>
                        </div>
                      </Col>
                      <Col span={18} className={'input-block'}>
                        <div className={'input-text'}>
                          <Title level={5}>Name</Title>
                        </div>
                      </Col>
                      <Col span={6}>
                        <div className={'form-label'}>
                          <Title level={5}>Date</Title>
                        </div>
                      </Col>
                      <Col span={18} className={'input-block'}>
                        <div className={'input-text'}>
                          <Title level={5}>
                            19/7/2021
                          </Title>
                        </div>
                      </Col>
                      <Col span={6}>
                        <div className={'form-label'}>
                          <Title level={5}>Duration</Title>
                        </div>
                      </Col>
                      <Col span={6} className={'input-block'}>
                        <div className={'input-text'}>
                          <Title level={5}>2 hours</Title>
                        </div>
                      </Col>
                      <Col span={6}>
                        <div className={'form-label'}>
                          <Title level={5}>Place</Title>
                        </div>
                      </Col>
                      <Col span={6} className={'input-block'}>
                        <div className={'input-text'}>
                          <Title level={5}>Teams</Title>
                        </div>
                      </Col>
                    </Row>
                  </Form>
                </Col>
              </Row>
            </Col>
            <Col span={12}>
              <Row>
                <Col span={24}>
                  <Form>
                    <Row>
                      <Col span={6}>
                        <div className={'form-label-team'}>
                          <Title level={5}>Meeting report</Title>
                        </div>
                      </Col>
                      <Col span={18} className={'input-block'}>
                        <div className={'input-text'}>
                          <Title level={5}>[Content to be determined]</Title>
                        </div>
                      </Col>
                    </Row>
                  </Form>
                </Col>
              </Row>
            </Col>
          </Row>
        </div>
      </div>
      <div className={'margin-20'}>
        <Row justify='space-between' >
          <Col span={1}>
            <UsergroupAddOutlined style={{ fontSize: '30px' }} />
          </Col>
          <Col span={23}>
            <Typography className={'font-title-member '}>
              EMPLOYEE PRESENTS
            </Typography>
          </Col>
        </Row>
      </div>
      <div className={'margin-20'}>
        <Table
          columns={tableColumns}
          dataSource={data}
          pagination={false}
        />
      </div>
    </AppLayout>
  )
}
export default TeamMeetingDetails;
