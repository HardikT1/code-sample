import React, { useState } from "react";
import { Typography, Input, Row, Col, Table, Button } from "antd";
import { SearchOutlined, UserAddOutlined, StockOutlined, ScheduleOutlined } from '@ant-design/icons';
import { useHistory } from "react-router";
import AppLayout from "../../components/layout/layout";


const ActivityTable = () => {
    const [selectionType, setSelectionType] = useState<'checkbox' | 'radio'>('checkbox');
    const history = useHistory();
    interface DataType {
        key: React.Key;
        name: string;
    }


    const columns = [
        {
            title: 'Date',
            dataIndex: 'date',
        },
        {
            title: 'Title',
            dataIndex: 'title',
            render: (text: string) => <a onClick={() => { history.push('/activities/activity-details') }}>{text}</a>,

        },
        {
            title: 'Report created by',
            dataIndex: 'reportCreate',
        },
        {
            title: 'Duration (h)',
            dataIndex: 'duration',
        },
        {
            title: 'participants (non-bnv)',
            dataIndex: 'participants',
        },

    ];

    const data: any = [];
    for (let i = 1; i <= 10; i++) {
        data.push({
            key: i,
            title: 'abbccc',
            date: "26/6/1997",
            reportCreate: "jackob marc",
            duration: "1,3",
            participants: 13
        });
    }

    const tableColumns = columns.map((item) => ({
        ...item,
    }));

    const rowSelection = {
        onChange: (selectedRowKeys: React.Key[], selectedRows: DataType[]) => {
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
        },
        getCheckboxProps: (record: DataType) => ({
            name: record.name,
        }),
    };

    return (
        <AppLayout>
            <div>
                <Row>
                    <Col span={1}>
                        <ScheduleOutlined style={{ fontSize: '35px' }} />
                    </Col>
                    <Col span={15}> <Typography className={'title-fontStyle '}>
                        LIST OF ACTIVITIES
                    </Typography></Col>
                    <Col span={8} >
                        <Row justify='space-around'>
                            <Col span={12}>
                                <Input size='middle' placeholder="To research.." prefix={<SearchOutlined />} />
                            </Col>
                            <Button type="primary" icon={<UserAddOutlined />}
                                onClick={() => { history.push('/activities/activity-report') }}
                            >
                                Activity Report
                            </Button>

                        </Row>
                    </Col>

                </Row>
            </div>
            <div className={'margin-20'}>
                <Table
                    rowSelection={{
                        type: selectionType,
                        ...rowSelection,
                    }}

                    columns={tableColumns}
                    dataSource={data}

                />
            </div>
            <div>
                <div>
                    <Row gutter={12}>
                        <Col className="gutter-row" span={4}>
                            <div><Button icon={<StockOutlined />}
                            >
                                View statistics
                            </Button></div>
                        </Col>
                    </Row>
                </div>
            </div>
        </AppLayout>

    )
}

export default ActivityTable;