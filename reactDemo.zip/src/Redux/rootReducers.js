import auth from './Auth/reducer';
import member from './Members/reducer';
import teamMeeting from './TeamMeeting/reducer'

export default {
    auth,
    member,
    teamMeeting
};