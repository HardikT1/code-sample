import { all } from 'redux-saga/effects';
import authSaga from './Auth/saga';
import membersSaga from './Members/saga';
import teamMeetingSaga from './TeamMeeting/saga'

export default function* rootSaga() {
    yield all([
        authSaga(),
        membersSaga(),
        teamMeetingSaga()
    ]);
}